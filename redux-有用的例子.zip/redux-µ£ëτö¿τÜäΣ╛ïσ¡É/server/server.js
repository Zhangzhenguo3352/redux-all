var express = require('express');
var mongoose = require('mongoose');
var DM_url = 'mongodb://127.0.0.1:27017';

// mongoose.connect(DM_url,{useMongoClient:true},function (err) {
//     if(err){
//         console.log("数据库连接失败！");
//     }else{
//         console.log("数据库连接成功！");
//         app.listen(port); 
//         console.log('moive start on port ' + port);  
//     }
// });

var db = mongoose.createConnection(DM_url); 
// 链接错误
db.on('error', function(error) {
    console.log('error',error);
});




// mongoose.connection.on('connected',function() {
// 		console.log('connect111')
// })
// const User = mongoose.model('user', new mongoose.Schema({
// 	user: {type: String, require: true},
// 	age: {type: Number, require: true}
// }))
// User.remove({username: 'zhangzhenguo'}, function(err,doc) {
// 	if(!err) {
// 		console.log('delete success')
// 		User.find({}, function(e, d) {
// 			console.log('d',d)
// 		})
// 	}
// })
const app = express();

app.get('/',function(req, res) {
	res.send('aaa')
})
app.get('/data',(req, res) => {
	res.json({name: 'zhangzhenguo',age: 112})
})
app.listen(9090,() => {
	console.log('9090')
})