import React, { Component } from 'react';


import logo from './logo.svg';
import './App.css';


class App extends Component {
  // 第一种
  App1Fn = () => {
    console.log('App1',)
  }
  // 第二种
  App2Fn() {
    console.log('App2')
    const store = this.props.store;
    store.dispatch({type: '加机关枪'})
  }
  // 第三种
  App3Fn() {
    console.log('App3')
  }
  // 第四种
  constructor() {
    super();
    this.App4Fn = this.App4Fn.bind(this)
  }
  App4Fn() {
    console.log('App4')

  }
  render() {

    const store = this.props.store;
    const num = store.getState()
    return (
      <div className="App">
        {/*第一种*/}
        <div ><button onClick={this.App1Fn}>点击按钮1</button></div>
        {/*第二种*/}
        <div ><button onClick={this.App2Fn.bind(this)}>点击按钮2   store  改变</button></div>
        {/*第二种*/}
        <div ><button onClick={() => this.App3Fn()}>点击按钮3</button></div>
        {/*第四种*/}
        <div ><button onClick={this.App4Fn}>点击按钮4</button></div>
        {num}
      </div>
    );
  }
}

export default App;
